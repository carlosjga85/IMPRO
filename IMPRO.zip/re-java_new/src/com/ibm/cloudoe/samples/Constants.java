package com.ibm.cloudoe.samples;

public class Constants {
	
	public static final String ID_KEY = "_id";
	public static final String TYPE_KEY = "type";
	public static final String GROUP_KEY = "group";
	public static final String JSON_KEY = "json";
	public static final String TEXT_KEY = "Text";
	
	public static final String CURRENT_EMPLOYEES_GROUP = "current_employees_group";

}
