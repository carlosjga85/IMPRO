package com.ibm.cloudoe.samples;

import java.util.List;

public class NewsText {
	
	String _id;
	String itemid;
	String title;
	String headline;
	String dateline;
	String text = "";
	List<String> pList;
	String entities;
		
}
