lib foler

The lib folder contains the libraries to build the war file, see build.xml